package org.objectweb.asm;

public abstract interface AnnotationVisitor
{
  public abstract void visit(String paramString, Object paramObject);
  
  public abstract void visitEnum(String paramString1, String paramString2, String paramString3);
  
  public abstract AnnotationVisitor visitAnnotation(String paramString1, String paramString2);
  
  public abstract AnnotationVisitor visitArray(String paramString);
  
  public abstract void visitEnd();
}


/* Location:              /home/matheus/Concierge stuff/remote-1.0.0.RC4.jar!/asm-3.0.jar!/org/objectweb/asm/AnnotationVisitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */