package org.objectweb.asm;

class Edge
{
  int a;
  Label b;
  Edge c;
}


/* Location:              /home/matheus/Concierge stuff/remote-1.0.0.RC4.jar!/asm-3.0.jar!/org/objectweb/asm/Edge.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */